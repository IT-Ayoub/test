import React from 'react';
import { TaskData, PomodoroState } from '../types/types';
import { TaskCard } from './TaskCard';

interface DayCardProps {
  day: string;
  label: string;
  tasks: TaskData[];
  progress: number;
  totalTime: string;
  darkMode: boolean;
  pomodoroState: PomodoroState | null;
  onTaskComplete: (day: string, taskId: string, completed: boolean) => void;
  onTaskDurationChange: (day: string, taskId: string, duration: number) => void;
  onTaskNotesChange: (day: string, taskId: string, notes: string) => void;
  onVideoDataChange: (day: string, taskId: string, field: string, value: string) => void;
  onStartPomodoro: (day: string, taskId: string) => void;
  onStopPomodoro: () => void;
}

const DayCard: React.FC<DayCardProps> = ({ 
  day,
  label,
  tasks,
  progress,
  totalTime,
  darkMode,
  pomodoroState,
  onTaskComplete,
  onTaskDurationChange,
  onTaskNotesChange,
  onVideoDataChange,
  onStartPomodoro,
  onStopPomodoro
}) => {
  return (
    <div className={`p-6 rounded-xl shadow-sm border transition-all ${
      darkMode 
        ? 'bg-slate-800 border-slate-700 shadow-slate-900/20' 
        : 'bg-white border-gray-200 shadow-gray-100/50'
    }`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
          {label}
        </h3>
        <div className="text-right">
          <div className={`text-sm ${darkMode ? 'text-slate-400' : 'text-gray-500'}`}>
            {Math.round(progress)}%
          </div>
          <div className={`text-sm ${darkMode ? 'text-slate-400' : 'text-gray-500'}`}>
            {totalTime}
          </div>
        </div>
      </div>
      
      <div className={`w-full bg-gray-200 rounded-full h-2 mb-4 ${darkMode ? 'bg-slate-700' : ''}`}>
        <div 
          className="bg-blue-500 h-2 rounded-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="space-y-3">
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            day={day}
            darkMode={darkMode}
            pomodoroState={pomodoroState}
            onTaskComplete={onTaskComplete}
            onTaskDurationChange={onTaskDurationChange}
            onTaskNotesChange={onTaskNotesChange}
            onVideoDataChange={onVideoDataChange}
            onStartPomodoro={onStartPomodoro}
            onStopPomodoro={onStopPomodoro}
          />
        ))}
      </div>
    </div>
  );
};

export default DayCard;
